CHATBOT DE CONTROL ESCOLAR UIM
==============================

ARCHIVO PRINCIPAL
- index.html

CÓMO ABRIRLO
1. Abre la carpeta.
2. Haz doble clic en index.html.
3. El chatbot se abrirá en el navegador y funcionará sin instalar programas.

CONFIGURAR ENLACES
1. Abre el chatbot.
2. Presiona "Configurar enlaces".
3. Captura:
   - WhatsApp de Control Escolar, incluyendo código de país y solo números.
   - Enlace de Finanzas.
   - Enlace de Trayectoria Estudiantil.
   - Enlace del departamento de Sistemas.
   - Tutorial para consultar boletas.
4. Presiona "Guardar configuración".

La configuración queda guardada en el navegador utilizado. Si se publica en una página web, cada navegador deberá guardar su propia configuración. Para dejar enlaces fijos para todos los usuarios, edita el objeto DEFAULT_CONFIG dentro de index.html.

PUBLICAR EN GITHUB PAGES
1. Crea un repositorio nuevo en GitHub.
2. Sube index.html a la raíz del repositorio.
3. En Settings > Pages, selecciona la rama principal y la carpeta raíz.
4. Guarda y abre la dirección que genere GitHub Pages.

OBSERVACIÓN
El documento fuente menciona "Cambio de carrera", pero no contiene el procedimiento detallado. Por ello, el chatbot dirige al alumno a Control Escolar sin inventar requisitos.
